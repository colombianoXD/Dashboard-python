from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required

# Create your views here.

def login_user(request):


    if not request.user.is_authenticated:
        
        if request.method == 'POST':
            user = request.POST['username']
            passwd = request.POST['pass']
            try:
                user_login = authenticate(request, username = user, password = passwd)
                if user_login:        
                    login(request, user_login)
                    return redirect('index') 
                else:
                    return render(request, 'login.html', context={'error': 'User doesn\'t exist'})    

            except User.DoesNotExist:
                return render(request, 'login.html', context={'error': 'Paila'})
    
        return render(request, 'login.html')
    
    else:
        return render(request, 'login.html', 
                      context={'message': '''User is already authenticated, please
                                logout to continue'''
                              })


@login_required
def logout_user(request):

        logout(request)

        return redirect('login')