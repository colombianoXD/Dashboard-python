from django.contrib import admin
from users.models import Perfil, Rol


# Register your models here.


@admin.register(Rol)
class RolAdmin(admin.ModelAdmin):

    list_display=('idrol', 'rol')



