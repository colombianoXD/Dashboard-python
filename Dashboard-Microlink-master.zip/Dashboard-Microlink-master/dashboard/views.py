from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required

from django.contrib.auth.models import User
from users.models import Perfil, Rol

# Create your views here.



@login_required
def index_view(request):

    return render(request, 'Dashboard/dashboard.html',
            context={'username': request.user.username,
                     'password': request.user.password,
                     'user': request.user,
            })


@login_required
def list_users(request):

    #import ipdb ; ipdb.set_trace()
    users = User.objects.all()
    print(users)

    return render(request, 'Dashboard/tables.html', context={'users': users, 'user': request.user})


def add_user(request):

    cargo = ''
    is_staff = False
    rol = 0

    import ipdb ; ipdb.set_trace()

    if request.method=="POST":
        nombre = request.POST['nombre']
        apellido = request.POST['apellido']
        correo = request.POST['correo']
        telefono = request.POST['telefono']
        id_usuario = request.POST['cedula']
        passwd = request.POST['passwd']
        passwd_confirm = request.POST['passwd_rp']

        if passwd != passwd_confirm:
            
            users = User.objects.all()
            return render(request, 'Dashboard/tables.html', context={'error': 'Passwords doesn\'t Match', 'users': users})

        if int(request.POST['cargo']) == 1:
            cargo = 'Operario'
        else:
            cargo = 'Nokia'
        if int(request.POST['rol']) == 1:
            is_staff = True
            rol = 1
        else:
            is_staff = False
            rol = 2

        user = User.objects.create_user(
            pk = id_usuario,
            username = 'id' + nombre,
            first_name = nombre,
            last_name = apellido,
            email = correo,
            is_staff = is_staff
        )

        perfil = Perfil.objects.create(user=user, cargo=cargo, telefono=telefono, rol_id = Rol.objects.get(idrol=rol)) 


    return redirect('tables')

        